package com.wallet.dao.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.wallet.bean.Customer;
import com.wallet.dao.WalletDao;
import com.wallet.dao.WalletDaoImpl;
import com.wallet.exception.WalletException;

public class WalletDaoImplTest {
	//WalletDao dao=new WalletDaoImpl();
	WalletDao dao=null;
	@Before
	public void setup() {
		dao=new WalletDaoImpl();
	}
	
	@After
	public void tearDown() {
		dao = null;
	}
	

	@Test
	public void testCreateAccount() {
		Customer c = new Customer();
		c.setAccNumber(1009);
		c.setName("Lavanya");
		c.setMobile("1234567890");
		c.setEmail("lavanya@mail.com");
		c.setAddress("Pune");
		c.setBalance(200000);
		c.setPin(222);
		
		
		try {
			dao.createAccount(c);
			Customer c1=dao.showBalance(1009);
			assertNotNull(c1);
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testShowBalance() {
		try {
			Customer c = dao.showBalance(1001);
			assertNotNull(c);
			Customer c1 = dao.showBalance(2000);
			assertNull(c1);
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}
	
	@Test
	public void testDepositPositive() {
		try {
			assertEquals(true, dao.deposit(1001, 20000));
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void testWithdrawPositive() {
		try {
			assertEquals(true, dao.withdraw(1002, 20000));
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void testFundTransferPositive() {
		try {
			assertEquals(true, dao.deposit(1001, 20000));
			assertEquals(true, dao.withdraw(1002, 20000));
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void testPrintTransaction() {
	try {
		String b = dao.printTransaction(1001);
		assertNotNull(b);
	} catch (WalletException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	
	



}
