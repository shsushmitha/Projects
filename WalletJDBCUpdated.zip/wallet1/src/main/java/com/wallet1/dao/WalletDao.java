package com.wallet1.dao;

import com.wallet1.bean.Customer;
import com.wallet1.exception.WalletException;

public interface WalletDao {
	long showBalance(long accNumber) throws WalletException;

	long createAccount(Customer cust) throws WalletException;

	boolean deposit(long num, double amount) throws WalletException;

	boolean withdraw(long num, double amount) throws WalletException;

	boolean fundTransfer(long num, long num1, double amount) throws WalletException;

	boolean printTransaction(long num) throws WalletException;

	int login(long accNumber) throws WalletException;
}
