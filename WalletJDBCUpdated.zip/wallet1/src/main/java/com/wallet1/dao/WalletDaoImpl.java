package com.wallet1.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.wallet1.bean.Customer;
import com.wallet1.bean.Transaction;
import com.wallet1.db.DBConnection;
import com.wallet1.exception.WalletException;

public class WalletDaoImpl implements WalletDao {
	Logger logger = Logger.getRootLogger();

	public WalletDaoImpl() {
		PropertyConfigurator.configure("resources//log4j.properties");
	}

	public int login(long accNumber) throws WalletException {
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement = null;
		int result = 0;
		ResultSet rs = null;
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.VALIDATE_PIN);

			preparedStatement.setLong(1, accNumber);
			rs = preparedStatement.executeQuery();
			if (rs.next()) {
				result = rs.getInt("pin");

			} else {
				throw new WalletException(" Such account number doesn't exist ");
			}

			return result;

		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new WalletException("Tehnical problem occured refer log");
		} finally {
			try {
				preparedStatement.close();
				connection.close();

			} catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");
			}
		}

	}

	public long showBalance(long accNumber) throws WalletException {
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement = null;

		ResultSet rs = null;
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.VIEW_BALANCE_CUSTOMER);

			preparedStatement.setLong(1, accNumber);
			rs = preparedStatement.executeQuery();
			rs.next();
			long result = (long) rs.getDouble("balance");
			return result;

		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new WalletException("Tehnical problem occured refer log");
		} finally {
			try {
				preparedStatement.close();
				connection.close();

			} catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");
			}
		}

	}

	public long createAccount(Customer cust) throws WalletException {
		Connection connection = DBConnection.getInstance().getConnection();

		PreparedStatement preparedStatement = null;
		ResultSet rs=null;
		int queryResult = 0;
		long accId = 0;
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.INSERT_CUSTOMER);

			preparedStatement.setString(1, cust.getName());
			preparedStatement.setString(2, cust.getMobile());
			preparedStatement.setString(3, cust.getEmail());
			preparedStatement.setString(4, cust.getAddress());
			preparedStatement.setDouble(5, cust.getBalance());
			preparedStatement.setInt(6, cust.getPin());

			queryResult = preparedStatement.executeUpdate();
			
			preparedStatement = connection.prepareStatement(QueryMapper.CUSTOMERID_QUERY_SEQUENCE);
			rs=preparedStatement.executeQuery();
			if(rs.next()) {
				accId=rs.getLong(1);
			}
			
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new WalletException("Inserting customer details failed ");

			}
			else
			{
				logger.info("account created successfully:");
				return accId;
			}
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new WalletException("Tehnical problem occured refer log");
		} finally {
			try {
				preparedStatement.close();
				connection.close();

			} catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");
			}
		}

	}

	public boolean deposit(long num, double amount) throws WalletException {
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement = null;

		int queryResult = 0;
		try {

			preparedStatement = connection.prepareStatement(QueryMapper.INSERT_TRANSACTION);
			preparedStatement.setLong(1, num);
			preparedStatement.setDouble(2, amount);
			preparedStatement.setString(3, "D");

			queryResult = preparedStatement.executeUpdate();

			preparedStatement = connection.prepareStatement(QueryMapper.UPDATE_CUSTOMER_DEPOSIT);
			preparedStatement.setDouble(1, amount);
			preparedStatement.setLong(2, num);
			queryResult = preparedStatement.executeUpdate();

			return true;
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new WalletException("Tehnical problem occured refer log");
		} finally {
			try {
				preparedStatement.close();
				connection.close();

			} catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");
			}
		}

	}

	public boolean withdraw(long num, double amount) throws WalletException {
		Connection connection = DBConnection.getInstance().getConnection();

		PreparedStatement preparedStatement = null;

		int queryResult = 0;
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.INSERT_TRANSACTION);
			preparedStatement.setLong(1, num);
			preparedStatement.setDouble(2, amount);
			preparedStatement.setString(3, "W");

			queryResult = preparedStatement.executeUpdate();
			preparedStatement = connection.prepareStatement(QueryMapper.UPDATE_CUSTOMER_WITHDRAW);
			preparedStatement.setDouble(1, amount);
			preparedStatement.setLong(2, num);
			queryResult = preparedStatement.executeUpdate();
			return true;
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new WalletException("Tehnical problem occured refer log");
		} finally {
			try {
				preparedStatement.close();
				connection.close();

			} catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");
			}
		}
	}

	public boolean fundTransfer(long num, long num1, double amount) throws WalletException {
		Connection connection = DBConnection.getInstance().getConnection();

		PreparedStatement preparedStatement = null;

		int queryResult = 0;

		try {
			preparedStatement = connection.prepareStatement(QueryMapper.INSERT_TRANSACTION);
			preparedStatement.setLong(1, num1);
			preparedStatement.setDouble(2, amount);
			preparedStatement.setString(3, "D");

			queryResult = preparedStatement.executeUpdate();
			preparedStatement = connection.prepareStatement(QueryMapper.UPDATE_CUSTOMER_DEPOSIT);
			preparedStatement.setDouble(1, amount);
			preparedStatement.setLong(2, num1);
			queryResult = preparedStatement.executeUpdate();

			preparedStatement = connection.prepareStatement(QueryMapper.INSERT_TRANSACTION);
			preparedStatement.setLong(1, num);
			preparedStatement.setDouble(2, amount);
			preparedStatement.setString(3, "W");

			queryResult = preparedStatement.executeUpdate();

			preparedStatement = connection.prepareStatement(QueryMapper.UPDATE_CUSTOMER_WITHDRAW);
			preparedStatement.setDouble(1, amount);
			preparedStatement.setLong(2, num);
			queryResult = preparedStatement.executeUpdate();
			return true;
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new WalletException("Tehnical problem occured refer log");
		} finally {
			try {
				preparedStatement.close();
				connection.close();

			} catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");
			}
		}
	}

	public boolean printTransaction(long num) throws WalletException {

		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		Transaction t = new Transaction();
		try {

			preparedStatement = connection.prepareStatement(QueryMapper.PRINT_TRANSACTION);

			preparedStatement.setLong(1, num);
			rs = preparedStatement.executeQuery();
			while (rs.next()) {

				t.setTrid(rs.getInt("trid"));
				t.setAccNumber(rs.getLong("accNumber"));
				t.setAmount(rs.getDouble("amount"));
				t.setTrtype(rs.getString("trtype"));
				System.out.println(t);

			}
			return true;

		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new WalletException("Tehnical problem occured refer log");
		} finally {
			try {
				preparedStatement.close();
				connection.close();

			} catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");
			}
		}

	}

}
