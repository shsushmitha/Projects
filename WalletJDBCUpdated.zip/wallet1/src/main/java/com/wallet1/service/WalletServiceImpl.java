package com.wallet1.service;

import com.wallet1.dao.WalletDao;
import com.wallet1.dao.WalletDaoImpl;
import com.wallet1.bean.Customer;
import com.wallet1.exception.WalletException;

public class WalletServiceImpl implements WalletService {
	WalletDao dao = new WalletDaoImpl();

	public long showBalance(long accNumber) throws WalletException {
		return dao.showBalance(accNumber);
	}

	public long createAccount(Customer cust) throws WalletException {
		return dao.createAccount(cust);
	}

	public boolean deposit(long num, double amount) throws WalletException {
		return dao.deposit(num, amount);
	}

	public boolean withdraw(long num, double amount) throws WalletException {
		return dao.withdraw(num, amount);
	}

	public boolean fundTransfer(long num, long num1, double amount) throws WalletException {
		return dao.fundTransfer(num, num1, amount);
	}

	public boolean printTransaction(long num) throws WalletException {
		return dao.printTransaction(num);
	}

	public boolean validateCustomer(Customer cust) throws WalletException {
		if (validateName(cust.getName()) && validateMobile(cust.getMobile()) && validateEmail(cust.getEmail()) && validateBalance(cust.getBalance())
				&& validateAddr(cust.getAddress())) {
			return true;
		}
		return false;
	}

	private boolean validateName(String name) throws WalletException {
		if (name.isEmpty() || name == null) {
			throw new WalletException("Employee Name cannot be empty");
		} else {
			if (!name.matches("[A-Z][A-Za-z ]{2,}")) {
				throw new WalletException("Name should start with a Capital letter followed by minimum of 2 alphabets");
			}
		}
		return true;
	}

	private boolean validateMobile(String mobile) throws WalletException {

		if (mobile.isEmpty() || mobile == null) {
			throw new WalletException("Mobile Number is mandatory");

		} else {
			if (!mobile.matches("\\d{10}")) {
				throw new WalletException("Mobile number should contain only 10 digits");
			}
		}
		return true;
	}

	private boolean validateEmail(String email) throws WalletException {
		if (!email.matches("[A-Za-z0-9_]+@+[a-z]+\\.com")) {
			throw new WalletException("Please enter a valid email Id");
		}
		return true;
	}

	private boolean validateAddr(String addr) throws WalletException {
		if (addr.isEmpty() || addr == null) {
			throw new WalletException("Address is mandatory");
		}
		return true;
	}
	private boolean validateBalance(double balance) throws WalletException {

		if (balance == 0) {
			throw new WalletException("Opening balance is mandatory");

		} else {
			if (!(balance>=100)) {
				throw new WalletException("Minimum opening balance is 100");
			}
		}
		return true;
	}
	@Override
	public int login(long accNumber) throws WalletException {
		return dao.login(accNumber);
	}

}
