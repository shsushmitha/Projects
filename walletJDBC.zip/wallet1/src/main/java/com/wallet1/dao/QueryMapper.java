package com.wallet1.dao;

public interface QueryMapper {
	public static final String INSERT_CUSTOMER="INSERT INTO customermaster VALUES(customermaster_sequence.NEXTVAL,?,?,?,?,?,?)";
	public static final String INSERT_TRANSACTION="INSERT INTO transaction VALUES(transaction_sequence.NEXTVAL,?,?,?)";
	public static final String UPDATE_CUSTOMER_DEPOSIT="UPDATE customermaster SET balance = balance + ? WHERE accnumber = ?";
	public static final String UPDATE_CUSTOMER_WITHDRAW="UPDATE customermaster SET balance = balance - ? WHERE accnumber = ?";
	public static final String VIEW_BALANCE_CUSTOMER="SELECT balance FROM customermaster WHERE accnumber = ?";
	public static final String PRINT_TRANSACTION ="SELECT trid, accnumber, amount, trtype FROM transaction WHERE accnumber = ?";
	public static final String VALIDATE_PIN="SELECT pin FROM customermaster WHERE accnumber = ?";
}

/******************TABLESCRIPT*******************
create table customermaster(accNumber number(10) PRIMARY KEY,
name varchar2(30) NOT NULL,
mobile varchar2(10) NOT NULL,
email varchar2(30) NOT NULL,
address varchar2(40) NOT NULL,
balance number,
pin number NOT NULL);

insert into customermaster values(1001,'sush','8939628680','sush@gmail.com','Chennai',100000,132);
insert into customermaster values(1002,'Pam','8888888888','pam@outlook.com','Banglore',150000,123);
insert into customermaster values(1003,'Sara','7777777777','sara@ymail.com','Chennai',200000,321);
insert into customermaster values(1004,'Ben','6666666666','ben@gmail.com','Hyderbad',400000,111);
insert into customermaster values(1005,'Anil','9898989898','anil@gmail.com','Delhi',250000,122);
insert into customermaster values(1006,'Sunil','6767676767','sunil@gmail.com','Pune',300000,333);

CREATE TABLE transaction
(
  trid INT PRIMARY KEY,
  accNumber NUMBER NOT NULL,
  amount NUMBER NOT NULL,
  trtype CHAR(1) NOT NULL,
FOREIGN KEY(accNumber)
REFERENCES customermaster (accNumber)
);


CREATE SEQUENCE customermaster_sequence START WITH 1 INCREMENT BY 1;

CREATE SEQUENCE transaction_sequence START WITH 1 INCREMENT BY 1;
************************************************/
